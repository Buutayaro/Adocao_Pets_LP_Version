const Pet = require('../models/Pet');

const index = async (req, res) => {
  const foods = await Food.readAll();

  res.render('pets/index.njk', { pets });
};

const readAll = async (req, res) => {
  const foods = await Pet.readAll();

  res.json(foods);
};

module.exports = { index, readAll };