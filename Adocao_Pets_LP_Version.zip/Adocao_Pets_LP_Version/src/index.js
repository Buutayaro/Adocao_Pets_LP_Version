import express from 'express';
import morgan from 'morgan';
import router from './routes.js';
import Pet from './database/Pets.js';

const fs = require("fs");
const express = require("express");
const nunjucks = require("nunjucks");
const routes = require("./routes");
const Seed = require("./seeders");
const Migration = require("./migrations");
const { dbFile } = require("./db");

const app = express();

app.set("view engine", "njk");

nunjucks.configure("src/views", {
  express: app,
  autoescape: true,
  noCache: true
});

(async () => {
  if (!fs.existsSync(dbFile)) {
    await Migration.up();
    await Seed.up();
  }
})();

app.use(express.json());

app.use(morgan('tiny'));

app.use(express.static('public'));

app.use(router);

Pet.loadSeed();

app.listen(3000, () => console.log('Server is running!'));