const { conn } = require("../database");

async function up() {
  const sql = `
  CREATE TABLE IF NOT EXISTS pets (
    name INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT,
    gender TEXT,
    size TEXT,
    vaccine TEXT,
    comorb TEXT,
    contact TEXT,
    age DOUBLE
  )
`;

  const db = await conn();

  await db.run(sql);
}

async function down() {
  const sql = `DROP TABLE foods`;

  const db = await conn();

  await db.run(sql);
}

module.exports = { up, down };
