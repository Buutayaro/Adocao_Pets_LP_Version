const { conn } = require("../db");

async function create(data) {
  const sql = `
  INSERT INTO
    pets (name, image, price)
  VALUES
    (?, ?, ?)
  `;

  const db = await conn();

  const {name, type, age, gender, size, comorb, contact} = data;

  const { lastID } = await db.run(sql, [name, type, age, gender, size, comorb, contact]);

  return lastID;
}

async function readAll() {
  const sql = `
  SELECT
    *
  FROM
    foods
`;

  const db = await conn();

  const foods = await db.all(sql);

  return foods;
}

module.exports = { create, readAll };
